const VConsole = require('./vconsole.min.js');

window.vConsole === undefined && (window.vConsole = new VConsole());
